<?php
/**
 * Created by PhpStorm.
 * User: rafa
 * Date: 10-May-20
 * Time: 11:28 AM
 */

$servername = "localhost";
$username = "root";
$password = "";
$db = "hms";

$conn = mysqli_connect("$servername","$username","$password","$db");

if(!$conn)
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit;
}
else {

    $fullName = $_POST["fullName"];
    $email = $_POST["email"];
    $phoneNo = $_POST["phoneNo"];
    $message = "User message"; //Replace the value with your post variable

    $sql = "INSERT INTO `contactrequest` (`fullName`, `email`, `phoneNo`, `message`) VALUES 
                               ('$fullName', '$email', '$phoneNo', '$message')";

    $result = mysqli_query($conn, $sql) or die("could not insert" . mysqli_error($conn));

    if ($result) {
        echo "<div class='alert alert-success'><strong>Success!</strong> Successfully Saved</div>";
    } else {
        echo "Bingo";
    }

    mysqli_close($conn);

}
